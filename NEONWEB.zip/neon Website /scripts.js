document.addEventListener('DOMContentLoaded', function () {
  const popup = document.getElementById('agePopup');
  const yesBtn = document.getElementById('yesBtn');
  const noBtn = document.getElementById('noBtn');
  const content = document.getElementById('mainContent');

  yesBtn.addEventListener('click', () => {
    popup.style.display = 'none';
    content.classList.remove('hidden');
    startTyping();
    scrollRevealInit();
  });

  noBtn.addEventListener('click', () => {
    alert('Sorry, you must be 21 or older to enter.');
    window.location.href = 'https://www.google.com/';
  });

  const text = "Welcome to Smokey’s Tobacco";
  let i = 0;
  function startTyping() {
    const typedText = document.getElementById('typedText');
    const interval = setInterval(() => {
      if (i < text.length) {
        typedText.textContent += text.charAt(i);
        i++;
      } else {
        clearInterval(interval);
      }
    }, 80);
  }

  // Scroll reveal for fade-in elements
  function scrollRevealInit() {
    const faders = document.querySelectorAll('.fade-in');
    const options = {
      threshold: 0.2
    };

    const appearOnScroll = new IntersectionObserver(function(entries, appearOnScroll) {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('visible');
        appearOnScroll.unobserve(entry.target);
      });
    }, options);

    faders.forEach(fader => {
      appearOnScroll.observe(fader);
    });
  }
});